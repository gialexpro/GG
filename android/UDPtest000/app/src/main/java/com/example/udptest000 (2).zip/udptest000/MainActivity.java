package com.example.udptest000;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.FrameLayout;

public class MainActivity extends AppCompatActivity {

    Button button;
    FrameLayout frameLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=findViewById(R.id.button);

        frameLayout=findViewById(R.id.framelayout);

        frameLayout.addView(new TrackpadView(getBaseContext()));

        button.setOnClickListener(v -> {
            UDP_Client Client = new UDP_Client();
            Client.Message = "HW";
            Client.Send();
        });
    }
}